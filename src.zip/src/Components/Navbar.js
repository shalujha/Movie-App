import React, { Component } from 'react'
import "./Navbar.css";

export default class Navbar extends Component {
    render() {
        return (
            <div className='Navbar-items'>
               <h1>Movies App</h1>
               <p>Favourites</p> 
            </div>
        )
    }
}
